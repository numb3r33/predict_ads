"""
This file contains all the utility functions.
"""
import pandas as pd
import hashlib

NR_BINS = 1000000


def load_data(tr_path, te_path):
    """
    Loads dataset
    
    Arguments:
    ----------
    tr_path: string
    te_path: string
    
    Return:
    -------
    train: dataframe
    test : dataframe or None
    """
    
    dtype = {
        'siteid': 'float32',
        'offerid': 'uint32',
        'category': 'uint32',
        'merchant': 'uint32',
        'click': 'uint8'
    }
    
    # mention dtypes to save some memory
    train = pd.read_csv(tr_path, dtype=dtype, parse_dates=['datetime'])
    test  = None
    
    if te_path is not None:
        del dtype['click']
        test  = pd.read_csv(te_path, dtype=dtype, parse_dates=['datetime'])
    
    return train, test

def train_in_test(train, test):
    """
    This function return only those instances where siteid in train
    is present in the test set as well.
    
    Arguments:
    ----------
    
    train: dataframe
    test : dataframe
    
    Return:
    -------
    
    train_sub: Subset of training set
    """
    
    return train.loc[test.siteid.isin(train.siteid).values, :]

def clean_browserids(train, test):
    """
    Cleans up browser names. There are multiple levels for this categorical variable
    but they in fact represent the same browser.
    
    Arguments:
    ----------
    
    train: dataframe
    test : dataframe
    
    Return:
    ----------
    
    train_cleaned: dataframe
    test_cleaned : dataframe
    
    """
    
    # map browser names
    replacement = {
    'Chrome': 'Google Chrome',
    'IE'    : 'Internet Explorer',
    'InternetExplorer': 'Internet Explorer',
    'Firefox': 'Mozilla Firefox',
    'Mozilla': 'Mozilla Firefox'
    }

    train.loc[:, 'browserid'] = train.browserid.replace(replacement)
    test.loc[:, 'browserid']  = test.browserid.replace(replacement)
    
    return train, test

def fill_missing_values(train, test, feature_name, missing_val):
    """
    This function helps fill missing values for a certain feature 
    with a missing value provided.
    
    Arguments:
    -----------
    
    train: dataframe
    test : dataframe
    feature_name: string
    missing_val : any data type
    
    Return:
    -----------
    train_imputed : dataframe
    test_imputed  : dataframe
    
    """
    
    train.loc[:, feature_name] = train[feature_name].fillna(missing_val)
    test.loc[:, feature_name]  = test[feature_name].fillna(missing_val)
    
    return train, test


def create_time_features(train, test):
    """
    This function decomposes date into hour
    
    Arguments:
    ----------
    
    train: dataframe
    test : dataframe
    
    Return:
    ---------
    train_with_hour: dataframe
    test_with_hour : dataframe
    """
    
    train = train.assign(hour=train.datetime.dt.hour)
    test  = test.assign(hour=test.datetime.dt.hour)
    
    return train, test

def replace_uncommon_levels(df_train, df_test, features):
    """
    This function replaces levels of categorical features which are present in train
    and not in test and vice-versa.
    
    Arguments:
    ----------
    
    df_train: dataframe
    df_test : dataframe
    features: list of categorical features
    
    Return:
    --------
    df_train_common: dataframe
    df_test_common : dataframe
    """
    
    for c in features:
        common = set(df_train[c]) & set(df_test[c])
        df_train.loc[~df_train[c].isin(common), c] = -9999
        df_test.loc[~df_test[c].isin(common), c] = -9999
        
    return df_train, df_test

def hashstr(input):
    return str(int(hashlib.md5(input.encode('utf8')).hexdigest(), 16)%(NR_BINS-1)+1)

        
  