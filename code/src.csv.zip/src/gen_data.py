import argparse
import collections
import time
import csv

from utils import *

parser = argparse.ArgumentParser()
parser.add_argument('tr_src_path', type=str)
parser.add_argument('te_src_path', type=str)
parser.add_argument('tr_dst_path', type=str)
parser.add_argument('te_dst_path', type=str)
parser.add_argument('tr_is_train', type=str)
parser.add_argument('te_is_train', type=str)

args = vars(parser.parse_args())

FIELDS     = ['click', 'siteid', 'offerid', 'category', 'merchant',
              'hour', 'countrycode', 'browserid', 'devid']

NEW_FIELDS = FIELDS + ['siteid_count', 'offerid_count', 'category_count', 'merchant_count', 'hour_count']

siteid_cnt      = collections.defaultdict(int)
offerid_cnt     = collections.defaultdict(int)
category_cnt    = collections.defaultdict(int)
merchant_cnt    = collections.defaultdict(int)
hour_cnt        = collections.defaultdict(int)

start = time.clock()

def scan(path):
    for i, row in enumerate(csv.DictReader(open(path)), start=1):
        if i % 1000000 == 0:
            print('{0:6.0f}    {1}m\n'.format(time.clock()-start,int(i/1000000)))
        
        siteid_cnt[row['siteid']]     += 1
        offerid_cnt[row['offerid']]   += 1
        category_cnt[row['category']] += 1
        merchant_cnt[row['merchant']] += 1
        hour_cnt[row['hour']]         += 1
        

def gen_data(src_path, dst_path, is_train):
    reader = csv.DictReader(open(src_path))
    writer = csv.DictWriter(open(dst_path, 'w'), NEW_FIELDS)
    
    writer.writeheader()
    
    for i, row in enumerate(reader, start=1):
        if i % 1000000 == 0:
            print('{0:6.0f}    {1}m\n'.format(time.clock()-start,int(i/1000000)))
            
        new_row = {}
        for field in FIELDS:
            if not is_train and field == 'click':
                continue
            
            new_row[field] = row[field]
            
        new_row['siteid_count']   = siteid_cnt[row['siteid']]
        new_row['offerid_count']  = offerid_cnt[row['offerid']]
        new_row['category_count'] = category_cnt[row['category']]
        new_row['merchant_count'] = merchant_cnt[row['merchant']]
        new_row['hour_count']     = hour_cnt[row['hour']]
        
        
        writer.writerow(new_row)
        
scan(args['tr_src_path'])
scan(args['te_src_path'])

print('===================SCAN COMPLETE==================================')
gen_data(args['tr_src_path'], args['tr_dst_path'], args['tr_is_train'] == 't')
gen_data(args['te_src_path'], args['te_dst_path'], args['te_is_train'] == 't')