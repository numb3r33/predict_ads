#!/usr/bin/env python3

"""
This module splits the training dataset into train and validation folds of equal size.
"""

import argparse
import numpy as np

from sklearn.model_selection import KFold

from utils import *

SEED = 123
np.random.seed(SEED)

parser = argparse.ArgumentParser()
parser.add_argument('tr_src_path', type=str)
parser.add_argument('te_src_path', type=str)
parser.add_argument('tr_sub', type=str)
parser.add_argument('fold0_dst_path', type=str)
parser.add_argument('fold1_dst_path', type=str)

args = vars(parser.parse_args())

def split_datasets(tr_src_path, te_src_path, tr_sub, fold0_dst_path, fold1_dst_path):
    print('Loading Dataset')
    train, test = load_data(tr_src_path, te_src_path)
    print('Dataset loaded successfully')
    
    if tr_sub == 't':
        print('Creating a subset of training data')
        train = train_in_test(train, test)
        print('Subset created successfully')
        
    kf = KFold(n_splits=2, shuffle=True, random_state=SEED)
    itr, ite = next(kf.split(train))
    
    print('Creating two folds out of training set')
    train.iloc[itr].to_csv(fold0_dst_path, index=False)
    train.iloc[ite].to_csv(fold1_dst_path, index=False)
    print('Folds saved successfully')
        

    
split_datasets(args['tr_src_path'],
               args['te_src_path'],
               args['tr_sub'],
               args['fold0_dst_path'],
               args['fold1_dst_path']
              )
        