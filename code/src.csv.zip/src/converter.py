import argparse, csv, collections, time

from utils import *

parser = argparse.ArgumentParser()
parser.add_argument('tr_src_path', type=str)
parser.add_argument('te_src_path', type=str)
parser.add_argument('tr_dst_path', type=str)
parser.add_argument('te_dst_path', type=str)
parser.add_argument('tr_is_train', type=str)
parser.add_argument('te_is_train', type=str)

args = vars(parser.parse_args())

fields = ['hour', 'countrycode', 'browserid', 'devid',
          'siteid', 'offerid', 'category', 'merchant',
          'siteid_count', 'offerid_count', 'category_count', 
          'merchant_count', 'hour_count']

start = time.clock()

def convert(src_path, dst_path, is_train=True):
    with open(dst_path, 'w') as f:
        for i, row in enumerate(csv.DictReader(open(src_path)), start=1):
            if i % 1000000 == 0:
                print('Took: {} seconds'.format((time.clock() - start)))
            
            feats = []
            
            for i, field in enumerate(fields, start=1):
                feats.append(str(i - 1) + ':' + hashstr(field+'-'+row[field]) + ':1')
            
            if is_train:
                f.write('{0} {1}\n'.format(row['click'], ' '.join(feats)))
            else:
                f.write('1 {0}\n'.format(' '.join(feats)))

convert(args['tr_src_path'], args['tr_dst_path'], args['tr_is_train'] == 't')
convert(args['te_src_path'], args['te_dst_path'], args['te_is_train'] == 't')
                